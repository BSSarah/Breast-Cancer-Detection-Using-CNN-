Breast tumor detection using convolutional neural networks( a binary classifier of mammogram images "Normal", "Abnormal (Tumor)".
In order to use the classification web app (templates/main.html) 
you have to Restat then RunAll the   code in the jupyter notebook 
(BCDraft01C.ipynb), that will create a "BCDraft01C.h5" file.
Thank you. 